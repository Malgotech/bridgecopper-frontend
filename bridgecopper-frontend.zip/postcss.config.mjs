export default {
  plugins: [],
};