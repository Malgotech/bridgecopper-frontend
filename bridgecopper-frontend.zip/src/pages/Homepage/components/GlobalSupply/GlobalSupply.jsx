import React, { useRef, useEffect } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Mousewheel } from "swiper/modules";
import "swiper/css";
import "swiper/css/mousewheel";
import Style from "./GlobalSupply.module.scss";
import cardImg1 from "../../../../assets/images/global-card-1.png";
import cardImg2 from "../../../../assets/images/global-card-2.png";
import cardImg3 from "../../../../assets/images/global-card-3.png";
import cardImg4 from "../../../../assets/images/global-card-4.png";


const cardData = [
  {
    title: "ENAMI Approved",
    desc: "Direct partnerships with ENAMI-authorized miners in Chile",
    image: cardImg1,
  },
  {
    title: "Vast Reserves",
    desc: "More than USD 10 billion in proven copper reserves",
    image: cardImg2,
  },
  {
    title: "Legacy Leadershi",
    desc: " Operations managed by a family office with over 80 years’ experience",
    image: cardImg3,
  },
  {
    title: "World Reach",
    desc: "Proven track record supplying global industrial, manufacturing, and energy.",
    image: cardImg4,
  },
];

const GlobalSupply = () => {
  return (
    <section className={Style.global_section}>
      <div className="custom-container">
        <div className={Style.global_section_head}>
          <div className={Style.global_section_head_left}>
            <h2 className={Style.h_text_1}>Global Supply Chain</h2>
            <p className={Style.p_text_1}>
              Bridge Copper integrates direct copper production with a{" "}
              <br className="break tab-break" /> seamless, world-class logistics
              network.
            </p>
          </div>
          <p className={Style.p_text_2}>
            Operating from our European headquarters in Austria, we{" "}
            <br className="break tab-break" /> connect elite mine owners in
            Chile and Arizona to clients across{" "}
            <br className="break tab-break" /> Asia, Europe, and the Middle
            East.
          </p>
        </div>
      </div>

      <div className="custom-container mt-5">
        <div className="row   g-5 desktop-hide">
          {cardData.map((card, index) => (
            <div className="col-md-6 col-12" key={index}>
              <div className={Style.global_card}>
                   <div className={Style.blur_bottom} />
                <img
                  src={card.image}
                  alt={card.title}
                  className={Style.card_img}
                />
                <div className={Style.card_content}>
                  <p className={Style.p_text_3}>{card.title}</p>
                  <p className={Style.p_text_4}>{card.desc}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default GlobalSupply;
